
"use strict";
var name_text = false;

$(document).ready(
  function()
  {
    tippenAnimaton();
  }
);
